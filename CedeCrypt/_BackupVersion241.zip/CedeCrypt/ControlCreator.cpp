#include "ControlCreator.h"

ControlCreator::ControlCreator()
{
}

ControlCreator::~ControlCreator()
{
}

void ControlCreator::SetUIHandler(UIHandler *uihandler)
{
	m_puihandler = uihandler;
}