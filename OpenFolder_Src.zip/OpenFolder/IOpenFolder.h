// IOpenFolder.h : Declaration of the COpenFolder

#ifndef __OPENFOLDER_H_
#define __OPENFOLDER_H_

/*lint -e537 */
#include "resource.h"    // main symbols
#include "OSVersion.h"
using namespace darka;
/*lint +e537 */

// * At the end of a line indicates my additions

#include <shlguid.h>
#include <comdef.h> // GUID values for "IShellExtInit" and "IContextMenu"
#include <shlobj.h> // The shell objects

struct __declspec(uuid("{000214E4-0000-0000-C000-000000000046}")) IContextMenu;
//struct __declspec(uuid("{000214F4-0000-0000-C000-000000000046}")) IContextMenu2;
//struct __declspec(uuid("{BCFCE0A0-EC17-11d0-8D10-00A0C90F2719}")) IContextMenu3;

	// Our Command Verbs
const char OPENFOLDERADMIN[] = "OpenFolderAdmin";
const wchar_t OPENFOLDERADMINU[] = L"OpenFolderAdmin";
const char OPENFOLDER[] = "OpenFolder";
const wchar_t OPENFOLDERU[] = L"OpenFolder";

/////////////////////////////////////////////////////////////////////////////
// COpenFolder

/*lint -e665 -e1550 -e1926 */
class ATL_NO_VTABLE OpenFolder : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<OpenFolder, &CLSID_OpenFolder>,
	public IShellExtInit, // So that Windows can initialize our shell extension *
	public IContextMenu // Context menu handler *
{
private:
    TCHAR szFileName_[_MAX_PATH]; // The folder / file selected
	OSVersion obVersion_;

	HBITMAP bmpMenu_; // For the shield 'icon' bitmap next to the menu item.
	MENUITEMINFO obAdminMenuData_; // Our 'Admin' menu item

		// Various ANSI and UNICODE descriptions for the context menu
	std::string menuText_;
	std::string menuTextAdmin_;
	std::string menuDesc_;
	std::string menuDescAdmin_;
	std::wstring menuDescU_;
	std::wstring menuDescAdminU_;

		// The command id's for our menu items
	unsigned int cmdOpenFolder_;
	unsigned int cmdOpenFolderAdmin_;
	unsigned int cmdOpenFolderOffset_; // These are the offets of our commands
	unsigned int cmdOpenFolderAdminOffset_;

public:
	OpenFolder()
		: menuText_("Open Command Prompt Here...")
		, menuTextAdmin_("Open an Elevated Command Prompt Here...")
		, menuDesc_("Opens a Command Prompt in the selected folder, or in the folder containing the selected file.")
		, menuDescAdmin_("Opens an Elevated (Admin) Command Prompt in the selected folder, or in the folder containing the selected file.")
		, menuDescU_(L"Opens a Command Prompt in the selected folder, or in the folder containing the selected file.")
		, menuDescAdminU_(L"Opens an Elevated (Admin) Command Prompt in the selected folder, or in the folder containing the selected file.")
		, cmdOpenFolder_(0)
		, cmdOpenFolderAdmin_(0)
		, cmdOpenFolderOffset_(0) // Our FIRST Command
		, cmdOpenFolderAdminOffset_(1) // Our Second Command
	{ 
		memset(szFileName_, 0, sizeof(szFileName_)); 
		ZeroMemory(&obAdminMenuData_, sizeof(obAdminMenuData_));
		obAdminMenuData_.cbSize = sizeof(obAdminMenuData_);

		bmpMenu_ = LoadBitmap(_Module.GetModuleInstance(), MAKEINTRESOURCE(IDB_SHIELDICON));

		obAdminMenuData_.fMask = MIIM_CHECKMARKS | MIIM_ID | MIIM_TYPE | MIIM_STATE;
		obAdminMenuData_.fType = MFT_STRING;
		obAdminMenuData_.dwTypeData = (LPSTR)menuTextAdmin_.c_str();
		obAdminMenuData_.cch = (UINT)menuTextAdmin_.length();
		obAdminMenuData_.fState = MFS_ENABLED;
		obAdminMenuData_.hbmpChecked = (HBITMAP)bmpMenu_;
		obAdminMenuData_.hbmpUnchecked = (HBITMAP)bmpMenu_;
	}

	~OpenFolder()
	{
		DeleteObject(bmpMenu_);
		bmpMenu_ = NULL;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_OPENFOLDER)

DECLARE_PROTECT_FINAL_CONSTRUCT()

/*lint -e778 */
BEGIN_COM_MAP(OpenFolder)
	COM_INTERFACE_ENTRY(IContextMenu) // *
	COM_INTERFACE_ENTRY(IShellExtInit) // *
END_COM_MAP()
/*lint +e778 */

	// IOpenFolder
public:
		// Our "IShellExtInit" implementation
	STDMETHOD(Initialize)(LPCITEMIDLIST pidlFolder, LPDATAOBJECT lpdObj, HKEY hKeyProgId); // *

		// Our "IContextMenu" implementation
	STDMETHOD(GetCommandString)(UINT_PTR idCmd, UINT uFlags, UINT *pwReserved, LPSTR pszName, UINT cchMax); // *
	STDMETHOD(QueryContextMenu)(HMENU hMenu, UINT indexMenu, UINT idCmdFirst, UINT idCmdLast, UINT uFlags); // *
	STDMETHOD(InvokeCommand)(LPCMINVOKECOMMANDINFO pici); // *
};
/*lint +e665 +e1550 +e1926 */

#endif //__OPENFOLDER_H_
//UINT_PTR
