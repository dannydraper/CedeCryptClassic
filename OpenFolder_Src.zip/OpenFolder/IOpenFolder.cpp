// IOpenFolder.cpp : Implementation of COpenFolder
#include "stdafx.h"
#include "OpenFolder.h"
#include "IOpenFolder.h"

#include <strsafe.h>

/////////////////////////////////////////////////////////////////////////////
// OpenFolder

// Everything *

	// Our "IShellExtInit" implementation
/*lint -e18 -e534 -e1776 */
HRESULT OpenFolder::Initialize(LPCITEMIDLIST pidlFolder, LPDATAOBJECT lpdObj, HKEY /* hKeyProgId */)
{
	if(lpdObj) // DATAOBJECT provided, so process the files/folders that it gives us
	{
			// Set up the format ( Same as clipboard format )
		FORMATETC obFmt =
		{
			CF_HDROP, (DVTARGETDEVICE FAR *)NULL,
			DVASPECT_CONTENT, -1, TYMED_HGLOBAL 
		};

		STGMEDIUM obMedium;
		HRESULT hres = lpdObj->GetData(&obFmt, &obMedium);

		if(SUCCEEDED(hres))
		{
				// Get the file data
			if(obMedium.hGlobal)
			{
				UINT cbFiles = DragQueryFile((HDROP)obMedium.hGlobal, (UINT)-1, 0, 0);
				if(cbFiles && cbFiles < 2)
				{
					DragQueryFile((HDROP)obMedium.hGlobal, 0, szFileName_, sizeof(szFileName_));
					ReleaseStgMedium(&obMedium);
					return S_OK;
				}
			}
		}

		ReleaseStgMedium(&obMedium);
	}
	else // No DATAOBJECT provided, so could be a right click on desktop or explorer backgrounds
	{
		if(pidlFolder) // Process the pidl instead
		{
			SHGetPathFromIDList(pidlFolder, szFileName_); // Convert the pidl to a path
			return S_OK;
		}
	}

	return E_INVALIDARG;
}

		// Our "IContextMenu" implementation
HRESULT OpenFolder::GetCommandString(UINT_PTR idCmd, UINT uFlags, UINT* /* pwReserved */, LPSTR pszName, UINT cchMax)
{
    HRESULT hr = E_INVALIDARG;

    if((idCmd != cmdOpenFolderOffset_) && (idCmd != cmdOpenFolderAdminOffset_)) // Is this one of our commands ?
        return hr;

	switch(uFlags)
	{
		case GCS_HELPTEXTA: // Ansi description
			if(idCmd == cmdOpenFolderAdminOffset_) 
				hr = StringCchCopyNA(pszName, cchMax, menuDescAdmin_.c_str(), cchMax);
			else
				hr = StringCchCopyNA(pszName, cchMax, menuDesc_.c_str(), cchMax);
		break; 

		case GCS_HELPTEXTW: // Unicode description
			if(idCmd == cmdOpenFolderAdminOffset_) 
				hr = StringCchCopyNW((LPWSTR)pszName, cchMax, menuDescAdminU_.c_str(), cchMax);
			else
				hr = StringCchCopyNW((LPWSTR)pszName, cchMax, menuDescU_.c_str(), cchMax);
		break; 

		case GCS_VERBA:
			if(idCmd == cmdOpenFolderAdminOffset_) 
				hr = StringCchCopyNA(pszName, cchMax, OPENFOLDERADMIN, cchMax);
			else
				hr = StringCchCopyNA(pszName, cchMax, OPENFOLDER, cchMax);
		break; 

		case GCS_VERBW:
			if(idCmd == cmdOpenFolderAdminOffset_) 
				hr = StringCchCopyNW((LPWSTR)pszName, cchMax, OPENFOLDERADMINU, cchMax);
			else
				hr = StringCchCopyNW((LPWSTR)pszName, cchMax, OPENFOLDERU, cchMax);
		break; 

		default:
			hr = S_OK;
		break; 
    }

    return hr;
}

HRESULT OpenFolder::QueryContextMenu(HMENU hMenu, UINT indexMenu, UINT idCmdFirst, UINT /* idCmdLast */, UINT /* uFlags */)
{
		// Add our new item to the shell's context menu

		// Add the normal 'Open ...'
	cmdOpenFolder_ = idCmdFirst;
	InsertMenu(hMenu, indexMenu++, MF_STRING | MF_BYPOSITION, idCmdFirst + cmdOpenFolderOffset_, menuText_.c_str());

		// Add the vista only 'Open Admin... ' menu item
		// We use InsertMenuItem() here as we want to specify a bitmap (The Shield Icon)
	if(obVersion_.IsWinVista()) // Elevated version of command prompt
	{ 
		cmdOpenFolderAdmin_ = idCmdFirst + 1;
		obAdminMenuData_.wID = idCmdFirst + cmdOpenFolderAdminOffset_;
		InsertMenuItem(hMenu, indexMenu++, TRUE, &obAdminMenuData_);
	}
	else
		cmdOpenFolderAdmin_ = cmdOpenFolder_; // Default this on non-vista PC's, else the menu's do not work

	return MAKE_HRESULT(SEVERITY_SUCCESS, FACILITY_NULL, cmdOpenFolderAdmin_ - idCmdFirst + 1);
}

		// And finally, open the Command Prompt itself
HRESULT OpenFolder::InvokeCommand(LPCMINVOKECOMMANDINFO pCmdInfo)
{
	if(pCmdInfo == NULL)
		return E_INVALIDARG;

		// Open an elevated 'Admin' command prompt ?
	bool bElevated = false;
	bool bProcess = false; // Process the verb ?

		// If lpVerb points to a string then process that to work out the command
	if(HIWORD(pCmdInfo->lpVerb) != 0)
	{
			// Warning: This can be sent by other verbs on the context menu, so check it's one of our verbs

			// Did we get a UNICODE verb ?
		if((pCmdInfo->cbSize == sizeof(CMINVOKECOMMANDINFOEX)) && (pCmdInfo->fMask & CMIC_MASK_UNICODE))
		{
			CMINVOKECOMMANDINFOEX* pUCmdInfo = (CMINVOKECOMMANDINFOEX*)pCmdInfo;

			if(_wcsicmp(pUCmdInfo->lpVerbW, OPENFOLDERADMINU) == 0) // L"OpenFolderAdmin" 
				bElevated = bProcess = true;
			else
			if(_wcsicmp(pUCmdInfo->lpVerbW, OPENFOLDERU) == 0) // L"OpenFolder"
				bProcess = true;
		}
		else // Not UNICODE
		{
			if(_stricmp(pCmdInfo->lpVerb, OPENFOLDERADMIN) == 0) // "OpenFolderAdmin" 
				bProcess = bElevated = true;
			else
			if(_stricmp(pCmdInfo->lpVerb, OPENFOLDER) == 0) // "OpenFolder"
				bProcess = true;
		}
	}
	else // Process the command id
	if(LOWORD(pCmdInfo->lpVerb) == cmdOpenFolderOffset_) // Open normal command prompt
		bProcess = true;
	else
	if(LOWORD(pCmdInfo->lpVerb) == cmdOpenFolderAdminOffset_) // Open elevated command prompt
		bElevated = bProcess = true;

	if(!bProcess)
		return E_INVALIDARG;

		// If we have been given a full path including a filename
		// then we only need the drive and folder info, so throw the filename away
	if((GetFileAttributes(szFileName_) & FILE_ATTRIBUTE_DIRECTORY) != FILE_ATTRIBUTE_DIRECTORY)
	{
		TCHAR szDrive[_MAX_DRIVE] = {'\0'};
		TCHAR szPath[_MAX_PATH] = {'\0'};

		_tsplitpath_s(szFileName_, szDrive, _MAX_DRIVE, szPath, _MAX_PATH, NULL, 0, NULL, 0);

		StringCchCopy(szFileName_, _MAX_PATH, szDrive);
		StringCchCat(szFileName_, _MAX_PATH, szPath);
	}

		// Start the appropriate command prompt
	SHELLEXECUTEINFO shExecInfo;
	ZeroMemory(&shExecInfo, sizeof(SHELLEXECUTEINFO));
	shExecInfo.cbSize = sizeof(SHELLEXECUTEINFO);
	shExecInfo.lpDirectory = szFileName_;
	shExecInfo.nShow = SW_SHOW;

	if(bElevated)
		shExecInfo.lpVerb = _T("runas"); // Run an elevated command prompt

	if((obVersion_.IsWin95()) || (obVersion_.IsWin98()))
		shExecInfo.lpFile = _T("command.com");
	else
		shExecInfo.lpFile = _T("cmd.exe");

	std::string lpParams = _T("/k cd /d "); // _T("/k cd /d d://download");
	lpParams += szFileName_;

	shExecInfo.lpParameters = lpParams.c_str(); // Specify the parameters to cmd.exe

	if(!ShellExecuteEx(&shExecInfo))
		return E_INVALIDARG;

	return S_OK;
}
/*lint +e18 +e534 +e1776 */
