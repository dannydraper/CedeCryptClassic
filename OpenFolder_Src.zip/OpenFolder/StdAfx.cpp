// stdafx.cpp : source file that includes just the standard includes
//  stdafx.pch will be the pre-compiled header
//  stdafx.obj will contain the pre-compiled type information

/*lint -e18 */
#include "stdafx.h"
/*lint +e18 */
